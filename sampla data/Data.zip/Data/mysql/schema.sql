

CREATE TABLE `customer` (
  `customer_id` int(9) NOT NULL AUTO_INCREMENT,
  `store_id` int(9) NULL,
  `customer_FirstName` varchar(100) NULL,
  `customer_lastName` varchar(255) NULL,
  `customer_email` varchar(255) NULL,
  `customer_birthdate` datetime NULL,
  `customer_address` varchar(255) NULL,
  `customer_phoneNumber` varchar(255) NULL,
  PRIMARY KEY (`customer_id`)
);

CREATE TABLE `posts` (
  `post_d` int(9) NOT NULL AUTO_INCREMENT,
  `customer_id` int(9) NULL,
  `title` LONGTEXT NULL,
  `description` LONGTEXT  NULL,
  `content` LONGTEXT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`post_d`)
);


CREATE TABLE `store` (
  `store_id` int(9) NOT NULL AUTO_INCREMENT,
  `store_name` varchar(100) NULL,
  `store_address` varchar(255) NULL,
  `store_emailaddress` varchar(255) NULL,
  `store_phonenumber` varchar(255) NULL,
  `store_managerFirstName` varchar(255) NULL,
  `store_managerLastName` varchar(255) NULL,
  `store_managerDOB` date NULL,
  `store_feedback` LONGTEXT NULL,
  PRIMARY KEY (`store_id`)
);


CREATE TABLE `customer_pictures` (
  `customer_pictures_id` int NOT NULL,
  `customers_id` int DEFAULT NULL,
  `picture_url` nvarchar(45) DEFAULT NULL,
  `picture_active` int DEFAULT NULL,
  PRIMARY KEY (`customer_pictures_id`)
)