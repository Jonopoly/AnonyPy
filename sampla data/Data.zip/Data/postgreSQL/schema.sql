CREATE TABLE "testing".customer (
  customer_id integereger NOT NULL,
  store_id integereger NULL,
  customer_FirstName text NULL,
  customer_lastName text NULL,
  customer_email text NULL,
  customer_birthdate text NULL,
  customer_address text NULL,
  customer_phoneNumber text NULL
  )


CREATE TABLE "testing".posts (
  post_d  integereger NULL,
  customer_id integereger NULL,
  title text NULL,
  description text NULL,
  content text NULL,
  date text NULL
  )

CREATE TABLE "testing".store (
  store_id  integer NOT NULL,
  store_name text NULL,
  store_address text NULL,
  store_emailaddress text NULL,
  store_phonenumber text NULL,
  store_managerFirstName text NULL,
  store_managerLastName text NULL,
  store_managerDOB text NULL,
  store_feedback text NULL
  ) 


CREATE TABLE "testing".customer_pictures (
  customer_pictures_id  integer NOT NULL,
  customers_id integer NULL,
  picture_url text NULL,
  picture_active integer NULL
  ) 