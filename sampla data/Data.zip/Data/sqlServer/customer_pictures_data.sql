INSERT INTO customer_pictures (customer_pictures_id,customers_id,picture_url,picture_active)
VALUES
(1, 2001,'image.jpg',0),
(2, 2001,'image.jpg',1),
(3, 2002,'image.jpg',1),
(4, 2003,'image.jpg',1),
(5, 2004,'image.jpg',0),
(6, 2004,'image.jpg',0),
(7, 2004,'image.jpg',1),
(8, 2005,'image.jpg',1),
(9, 2006,'image.jpg',1);