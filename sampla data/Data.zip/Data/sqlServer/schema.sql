CREATE TABLE customer (
  customer_id int NOT NULL,
  store_id int NULL,
  customer_FirstName nvarchar(250) NULL,
  customer_lastName nvarchar(250) NULL,
  customer_email nvarchar(250) NULL,
  customer_birthdate datetime NULL,
  customer_address nvarchar(250) NULL,
  customer_phoneNumber nvarchar(250) NULL,
  ) ON [PRIMARY]
GO

CREATE TABLE posts (
  post_d  int NOT NULL,
  customer_id int NULL,
  title nvarchar(250) NULL,
  description nvarchar(250) NULL,
  content nvarchar(250) NULL,
  date datetime NULL
  ) ON [PRIMARY]
GO


CREATE TABLE store (
  store_id  int NOT NULL,
  store_name varchar(100) NULL,
  store_address varchar(255) NULL,
  store_emailaddress varchar(255) NULL,
  store_phonenumber varchar(255) NULL,
  store_managerFirstName varchar(255) NULL,
  store_managerLastName varchar(255) NULL,
  store_managerDOB datetime NULL,
  store_feedback nvarchar(250) NULL
  ) ON [PRIMARY]
GO

CREATE TABLE customer_pictures (
  customer_pictures_id  int NOT NULL,
  customers_id int NULL,
  picture_url nvarchar(45) NULL,
  picture_active int NULL
  ) ON [PRIMARY]
GO